/**
 * Created by pollo_000 on 11/27/2016.
 */

/*************************************************************/
/****************** Arithmetic Operations ********************/
/*************************************************************/

print('10' + 10);//Implicit conversion happens for second operand (that's converted t string)
print('10' - 10);//Implicit conversion happens for first operand
print('10' * 10);//Implicit conversion happens for first operand
print('10' / 10);//Implicit conversion happens for first operand

/*********************************** FUNCTIONS *********************************************************/

function print(message) {
    console.log(message);
}