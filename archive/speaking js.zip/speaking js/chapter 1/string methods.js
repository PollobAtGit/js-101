'abc'.length;
'pollob'.toUpperCase();
'pollob'.slice(2); //From 2nd index character to end : 'llob'
'pollob'.slice(2, 3); //From 2nd index character to (end - 1) index character : 'l'
'pollob'.slice(2, 5); //From 2nd index character to (end - 1) index character : 'llo'

// Try with negative index for slice